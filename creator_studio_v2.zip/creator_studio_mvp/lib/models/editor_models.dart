enum EditorType { photo, video }

enum PhotoFilter { original, vivid, mono, warm, cool, fade }

extension PhotoFilterName on PhotoFilter {
  String get label {
    switch (this) {
      case PhotoFilter.original: return 'Original';
      case PhotoFilter.vivid: return 'Vivid';
      case PhotoFilter.mono: return 'Mono';
      case PhotoFilter.warm: return 'Warm';
      case PhotoFilter.cool: return 'Cool';
      case PhotoFilter.fade: return 'Fade';
    }
  }
}
