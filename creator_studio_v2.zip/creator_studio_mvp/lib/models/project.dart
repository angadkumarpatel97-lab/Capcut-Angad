import 'package:flutter/foundation.dart';

class TimelineClip {
  final String id;
  final String name;
  final Duration duration;
  final String type; // video, photo, audio, text

  const TimelineClip({
    required this.id,
    required this.name,
    required this.duration,
    required this.type,
  });
}

class EditorProject extends ChangeNotifier {
  String name;
  final List<TimelineClip> clips = [];

  EditorProject({this.name = 'Untitled Project'});

  Duration get totalDuration =>
      clips.fold(Duration.zero, (a, b) => a + b.duration);

  void addClip(TimelineClip clip) {
    clips.add(clip);
    notifyListeners();
  }

  void removeClip(String id) {
    clips.removeWhere((c) => c.id == id);
    notifyListeners();
  }

  void rename(String value) {
    name = value;
    notifyListeners();
  }
}
