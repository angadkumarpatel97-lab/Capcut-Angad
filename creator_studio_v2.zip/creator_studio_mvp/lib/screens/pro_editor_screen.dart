import 'package:flutter/material.dart';
import '../models/project.dart';

class ProEditorScreen extends StatefulWidget {
  const ProEditorScreen({super.key});

  @override
  State<ProEditorScreen> createState() => _ProEditorScreenState();
}

class _ProEditorScreenState extends State<ProEditorScreen> {
  final project = EditorProject();
  double playhead = 0.28;
  bool playing = false;
  int selectedTool = 0;
  String aspect = '9:16';

  final tools = const [
    (Icons.content_cut_rounded, 'Trim'),
    (Icons.swap_horiz_rounded, 'Split'),
    (Icons.auto_awesome_rounded, 'Effects'),
    (Icons.filter_vintage_rounded, 'Filters'),
    (Icons.text_fields_rounded, 'Text'),
    (Icons.music_note_rounded, 'Music'),
    (Icons.speed_rounded, 'Speed'),
    (Icons.crop_rounded, 'Crop'),
  ];

  @override
  void initState() {
    super.initState();
    project
      ..addClip(const TimelineClip(
        id: '1',
        name: 'Main video',
        duration: Duration(seconds: 8),
        type: 'video',
      ))
      ..addClip(const TimelineClip(
        id: '2',
        name: 'B-roll',
        duration: Duration(seconds: 5),
        type: 'video',
      ))
      ..addClip(const TimelineClip(
        id: '3',
        name: 'Title',
        duration: Duration(seconds: 3),
        type: 'text',
      ));
  }

  void _showSheet(String title, List<String> items) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF151720),
      showDragHandle: true,
      builder: (_) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            Text(title,
                style: const TextStyle(
                    fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            ...items.map((x) => ListTile(
                  leading: const Icon(Icons.circle_outlined),
                  title: Text(x),
                  onTap: () => Navigator.pop(context),
                )),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF08090D),
      appBar: AppBar(
        title: GestureDetector(
          onTap: () => _renameProject(),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(project.name,
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(width: 5),
              const Icon(Icons.edit_outlined, size: 16),
            ],
          ),
        ),
        actions: [
          IconButton(
            tooltip: 'Undo',
            onPressed: () {},
            icon: const Icon(Icons.undo_rounded),
          ),
          IconButton(
            tooltip: 'Redo',
            onPressed: () {},
            icon: const Icon(Icons.redo_rounded),
          ),
          TextButton(
            onPressed: () => _showSheet(
              'Export quality',
              ['1080p • 30 FPS', '1080p • 60 FPS', '4K • 30 FPS', '4K • 60 FPS'],
            ),
            child: const Text('Export'),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            flex: 5,
            child: Container(
              margin: const EdgeInsets.fromLTRB(16, 10, 16, 10),
              decoration: BoxDecoration(
                color: const Color(0xFF151720),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Stack(
                children: [
                  Center(
                    child: AspectRatio(
                      aspectRatio: aspect == '9:16' ? 9 / 16 : 16 / 9,
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [Color(0xFF262039), Color(0xFF11141D)],
                          ),
                        ),
                        child: const Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.play_circle_fill_rounded, size: 64),
                              SizedBox(height: 8),
                              Text('Preview',
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w700)),
                              SizedBox(height: 4),
                              Text('GPU preview surface',
                                  style: TextStyle(color: Colors.white54)),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 14,
                    bottom: 14,
                    child: FilledButton.tonalIcon(
                      onPressed: () => setState(() => playing = !playing),
                      icon: Icon(playing
                          ? Icons.pause_rounded
                          : Icons.play_arrow_rounded),
                      label: Text(playing ? 'Pause' : 'Play'),
                    ),
                  ),
                  Positioned(
                    right: 14,
                    bottom: 14,
                    child: DropdownButton<String>(
                      value: aspect,
                      dropdownColor: const Color(0xFF20232E),
                      items: const ['9:16', '16:9', '1:1', '4:5']
                          .map((x) =>
                              DropdownMenuItem(value: x, child: Text(x)))
                          .toList(),
                      onChanged: (v) => setState(() => aspect = v ?? aspect),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Container(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              decoration: const BoxDecoration(
                color: Color(0xFF101219),
                borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
              ),
              child: Column(
                children: [
                  SizedBox(
                    height: 64,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: tools.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (_, i) => GestureDetector(
                        onTap: () {
                          setState(() => selectedTool = i);
                          _showSheet(tools[i].$2, _options(tools[i].$2));
                        },
                        child: Container(
                          width: 66,
                          decoration: BoxDecoration(
                            color: selectedTool == i
                                ? const Color(0xFF7C5CFC)
                                : const Color(0xFF191C25),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(tools[i].$1, size: 21),
                              const SizedBox(height: 4),
                              Text(tools[i].$2,
                                  style: const TextStyle(fontSize: 10)),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: Stack(
                      children: [
                        ListView(
                          padding: const EdgeInsets.only(top: 6),
                          children: [
                            _track('Video', project.clips
                                .where((c) => c.type == 'video')
                                .map((c) => c.name)
                                .toList()),
                            const SizedBox(height: 8),
                            _track('Text', project.clips
                                .where((c) => c.type == 'text')
                                .map((c) => c.name)
                                .toList()),
                            const SizedBox(height: 8),
                            _track('Audio', const ['Music']),
                          ],
                        ),
                        Positioned(
                          left: 10 + MediaQuery.sizeOf(context).width * playhead,
                          top: 0,
                          bottom: 0,
                          child: Container(width: 2, color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                  Slider(
                    value: playhead,
                    onChanged: (v) => setState(() => playhead = v),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<String> _options(String tool) {
    switch (tool) {
      case 'Trim':
        return ['Set start', 'Set end', 'Trim selection'];
      case 'Split':
        return ['Split at playhead', 'Split into 3', 'Remove selection'];
      case 'Effects':
        return ['Glow', 'Shake', 'Zoom', 'Retro', 'Glitch'];
      case 'Filters':
        return ['Original', 'Vivid', 'Cinematic', 'Warm', 'Cool', 'Mono'];
      case 'Text':
        return ['Title', 'Subtitle', 'Caption', 'Animated text'];
      case 'Music':
        return ['Import audio', 'Voiceover', 'Sound effects'];
      case 'Speed':
        return ['0.25x', '0.5x', '1x', '1.5x', '2x', '4x'];
      case 'Crop':
        return ['9:16', '16:9', '1:1', '4:5'];
      default:
        return ['Option'];
    }
  }

  Widget _track(String label, List<String> clips) {
    return SizedBox(
      height: 48,
      child: Row(
        children: [
          SizedBox(
            width: 48,
            child: Text(label,
                style: const TextStyle(
                    color: Colors.white54, fontSize: 11)),
          ),
          Expanded(
            child: Row(
              children: [
                for (int i = 0; i < clips.length; i++)
                  Expanded(
                    child: Container(
                      height: 42,
                      margin: const EdgeInsets.only(right: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: const Color(0xFF272B38),
                        border: Border.all(color: Colors.white10),
                      ),
                      alignment: Alignment.center,
                      child: Text(clips[i],
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 11)),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _renameProject() async {
    final c = TextEditingController(text: project.name);
    final value = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Project name'),
        content: TextField(controller: c, autofocus: true),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(context, c.text.trim()),
              child: const Text('Save')),
        ],
      ),
    );
    if (value != null && value.isNotEmpty) {
      setState(() => project.rename(value));
    }
  }
}
