import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class VideoEditorScreen extends StatefulWidget {
  final String path;
  const VideoEditorScreen({super.key, required this.path});

  @override
  State<VideoEditorScreen> createState() => _VideoEditorScreenState();
}

class _VideoEditorScreenState extends State<VideoEditorScreen> {
  late final VideoPlayerController _controller;
  bool _muted = false;
  double _speed = 1.0;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.file(
      File(widget.path),
    )..initialize().then((_) {
        if (mounted) setState(() {});
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _togglePlay() {
    if (_controller.value.isPlaying) {
      _controller.pause();
    } else {
      _controller.play();
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Video Editor',
            style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          TextButton(
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Export pipeline is ready to connect.')),
            ),
            child: const Text('Export'),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: _controller.value.isInitialized
                  ? AspectRatio(
                      aspectRatio: _controller.value.aspectRatio,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          VideoPlayer(_controller),
                          GestureDetector(
                            onTap: _togglePlay,
                            child: AnimatedOpacity(
                              opacity: _controller.value.isPlaying ? 0 : 1,
                              duration: const Duration(milliseconds: 150),
                              child: const CircleAvatar(
                                radius: 34,
                                child: Icon(Icons.play_arrow_rounded, size: 42),
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  : const CircularProgressIndicator(),
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
            decoration: const BoxDecoration(
              color: Color(0xFF101219),
              borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
            ),
            child: SafeArea(
              top: false,
              child: Column(
                children: [
                  if (_controller.value.isInitialized) ...[
                    VideoProgressIndicator(
                      _controller,
                      allowScrubbing: true,
                      padding: const EdgeInsets.symmetric(vertical: 8),
                    ),
                    Row(
                      children: [
                        const Text('0:00'),
                        const Spacer(),
                        Text(_format(_controller.value.duration)),
                      ],
                    ),
                  ],
                  const SizedBox(height: 12),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        _VideoTool(Icons.content_cut_rounded, 'Trim'),
                        _VideoTool(Icons.crop_rounded, 'Crop'),
                        _VideoTool(Icons.text_fields_rounded, 'Text'),
                        _VideoTool(Icons.music_note_rounded, 'Music'),
                        _VideoTool(Icons.auto_awesome_rounded, 'Effects'),
                        _VideoTool(Icons.filter_vintage_rounded, 'Filters'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      const Text('Speed'),
                      const SizedBox(width: 8),
                      for (final speed in [0.5, 1.0, 1.5, 2.0])
                        Padding(
                          padding: const EdgeInsets.only(right: 6),
                          child: ChoiceChip(
                            label: Text('${speed}x'),
                            selected: _speed == speed,
                            onSelected: (_) {
                              setState(() => _speed = speed);
                              _controller.setPlaybackSpeed(speed);
                            },
                          ),
                        ),
                      IconButton(
                        tooltip: 'Mute',
                        onPressed: () {
                          setState(() => _muted = !_muted);
                          _controller.setVolume(_muted ? 0 : 1);
                        },
                        icon: Icon(_muted
                            ? Icons.volume_off_rounded
                            : Icons.volume_up_rounded),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () {},
                          icon: const Icon(Icons.add_rounded),
                          label: const Text('Add clip'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Export: connect native FFmpeg/MediaCodec pipeline here.'),
                            ),
                          ),
                          icon: const Icon(Icons.ios_share_rounded),
                          label: const Text('Export 4K'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _format(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }
}

class _VideoTool extends StatelessWidget {
  final IconData icon;
  final String label;
  const _VideoTool(this.icon, this.label);

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(right: 8),
    child: ActionChip(
      avatar: Icon(icon, size: 18),
      label: Text(label),
      onPressed: () {},
    ),
  );
}
