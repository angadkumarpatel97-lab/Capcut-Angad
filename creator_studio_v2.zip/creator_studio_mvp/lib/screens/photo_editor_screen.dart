import 'dart:io';
import 'package:flutter/material.dart';
import '../models/editor_models.dart';
import '../widgets/gradient_button.dart';

class PhotoEditorScreen extends StatefulWidget {
  final String path;
  const PhotoEditorScreen({super.key, required this.path});

  @override
  State<PhotoEditorScreen> createState() => _PhotoEditorScreenState();
}

class _PhotoEditorScreenState extends State<PhotoEditorScreen> {
  PhotoFilter _filter = PhotoFilter.original;
  double _brightness = 0;
  double _contrast = 1;
  double _saturation = 1;
  String _ratio = 'Original';

  List<double> get _matrix {
    final b = _brightness * 255;
    final c = _contrast;
    final s = _saturation;
    final warm = _filter == PhotoFilter.warm ? 12.0 : 0.0;
    final cool = _filter == PhotoFilter.cool ? 12.0 : 0.0;
    final mono = _filter == PhotoFilter.mono ? 0.0 : s;
    final fade = _filter == PhotoFilter.fade ? 0.85 : 1.0;

    // Lightweight preview matrix; final rendering should use a GPU/native
    // pipeline for production export.
    return <double>[
      c * mono, 0, 0, 0, b + warm,
      0, c * mono, 0, 0, b,
      0, 0, c * mono, 0, b - cool,
      0, 0, 0, fade, 0,
    ];
  }

  void _showTextDialog() {
    final controller = TextEditingController(text: 'Your title');
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Add text'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(
            hintText: 'Type your title or caption',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Text added: ${controller.text}')),
              );
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Photo Editor',
            style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          TextButton(
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Export pipeline is ready to connect.')),
            ),
            child: const Text('Export'),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: AspectRatio(
                aspectRatio: 4 / 5,
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: ColorFiltered(
                    colorFilter: ColorFilter.matrix(_matrix),
                    child: Image.file(
                      File(widget.path),
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => const Center(
                        child: Icon(Icons.broken_image_outlined, size: 56),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          Container(
            decoration: const BoxDecoration(
              color: Color(0xFF101219),
              borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
            ),
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
            child: SafeArea(
              top: false,
              child: Column(
                children: [
                  SizedBox(
                    height: 46,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        _Tool('Adjust', Icons.tune_rounded, () {}),
                        _Tool('Filters', Icons.filter_vintage_rounded, () {}),
                        _Tool('Crop', Icons.crop_rounded, () {}),
                        _Tool('Text', Icons.text_fields_rounded, _showTextDialog),
                        _Tool('Sticker', Icons.emoji_emotions_outlined, () {}),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  _SliderRow('Brightness', _brightness, -1, 1,
                      (v) => setState(() => _brightness = v)),
                  _SliderRow('Contrast', _contrast, 0.5, 1.8,
                      (v) => setState(() => _contrast = v)),
                  _SliderRow('Saturation', _saturation, 0, 2,
                      (v) => setState(() => _saturation = v)),
                  const SizedBox(height: 8),
                  SizedBox(
                    height: 42,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        for (final f in PhotoFilter.values)
                          Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: ChoiceChip(
                              label: Text(f.label),
                              selected: _filter == f,
                              onSelected: (_) => setState(() => _filter = f),
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      const Text('Aspect'),
                      const SizedBox(width: 10),
                      DropdownButton<String>(
                        value: _ratio,
                        items: ['Original', '1:1', '4:5', '9:16', '16:9']
                            .map((x) => DropdownMenuItem(value: x, child: Text(x)))
                            .toList(),
                        onChanged: (v) => setState(() => _ratio = v ?? 'Original'),
                      ),
                      const Spacer(),
                      GradientButton(
                        label: 'Done',
                        icon: Icons.check_rounded,
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Tool extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  const _Tool(this.label, this.icon, this.onTap);

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(right: 8),
    child: ActionChip(
      avatar: Icon(icon, size: 18),
      label: Text(label),
      onPressed: onTap,
    ),
  );
}

class _SliderRow extends StatelessWidget {
  final String label;
  final double value, min, max;
  final ValueChanged<double> onChanged;
  const _SliderRow(this.label, this.value, this.min, this.max, this.onChanged);

  @override
  Widget build(BuildContext context) => Row(
    children: [
      SizedBox(width: 82, child: Text(label, style: const TextStyle(fontSize: 12))),
      Expanded(child: Slider(value: value, min: min, max: max, onChanged: onChanged)),
    ],
  );
}
