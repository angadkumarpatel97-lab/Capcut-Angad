import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../widgets/gradient_button.dart';
import 'photo_editor_screen.dart';
import 'video_editor_screen.dart';
import 'pro_editor_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _picker = ImagePicker();

  Future<void> _pickPhoto() async {
    final file = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 100,
    );
    if (!mounted || file == null) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PhotoEditorScreen(path: file.path),
      ),
    );
  }

  Future<void> _pickVideo() async {
    final file = await _picker.pickVideo(source: ImageSource.gallery);
    if (!mounted || file == null) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => VideoEditorScreen(path: file.path),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
              sliver: SliverToBoxAdapter(
                child: Row(
                  children: [
                    Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        gradient: const LinearGradient(
                          colors: [Color(0xFF7C5CFC), Color(0xFFB34DFF)],
                        ),
                      ),
                      child: const Icon(Icons.auto_awesome_rounded),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Creator Studio',
                              style: TextStyle(
                                fontSize: 21,
                                fontWeight: FontWeight.w800,
                              )),
                          Text('Photo & Video Editor',
                              style: TextStyle(color: Colors.white60)),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: const Icon(Icons.settings_outlined),
                    ),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 28, 20, 16),
              sliver: SliverToBoxAdapter(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Create something amazing',
                        style: TextStyle(
                          fontSize: 29,
                          fontWeight: FontWeight.w900,
                          height: 1.1,
                        )),
                    const SizedBox(height: 8),
                    const Text(
                      'Edit photos and videos with a fast, modern workflow.',
                      style: TextStyle(color: Colors.white60, fontSize: 15),
                    ),
                    const SizedBox(height: 22),
                    GradientButton(
                      label: 'Edit Photo',
                      icon: Icons.image_rounded,
                      onPressed: _pickPhoto,
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: OutlinedButton.icon(
                        onPressed: _pickVideo,
                        icon: const Icon(Icons.movie_creation_outlined),
                        label: const Text('Edit Video'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          side: const BorderSide(color: Colors.white24),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: OutlinedButton.icon(
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const ProEditorScreen()),
                        ),
                        icon: const Icon(Icons.timeline_rounded),
                        label: const Text('Open Pro Editor'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: const Color(0xFFD0C2FF),
                          side: const BorderSide(color: Color(0xFF5D48A6)),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
              sliver: SliverToBoxAdapter(
                child: _FeatureGrid(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FeatureGrid extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final items = [
      (Icons.tune_rounded, 'Pro Adjust', 'Brightness, contrast & color'),
      (Icons.filter_vintage_rounded, 'Filters', 'Vivid, warm, cool & mono'),
      (Icons.text_fields_rounded, 'Text', 'Add titles and captions'),
      (Icons.speed_rounded, 'Speed', 'Slow motion & fast motion'),
      (Icons.crop_rounded, 'Crop', 'Social media aspect ratios'),
      (Icons.high_quality_rounded, '4K Ready', 'Export pipeline ready'),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 1.35,
      ),
      itemBuilder: (_, i) {
        final item = items[i];
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFF12141B),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white10),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(item.$1, color: const Color(0xFFB89EFF)),
              const Spacer(),
              Text(item.$2,
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(item.$3,
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 12,
                  )),
            ],
          ),
        );
      },
    );
  }
}
