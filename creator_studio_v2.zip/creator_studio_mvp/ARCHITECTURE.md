# Creator Studio architecture

lib/
  main.dart
  models/
    editor_models.dart
  widgets/
    gradient_button.dart
  screens/
    home_screen.dart
    photo_editor_screen.dart
    video_editor_screen.dart

Recommended production modules for v2:
- services/media_picker_service.dart
- services/photo_render_service.dart
- services/video_render_service.dart
- services/project_store.dart
- models/project.dart
- models/timeline.dart
- screens/projects_screen.dart
- screens/export_screen.dart

Rendering strategy:
1. Flutter owns navigation, UI and editor state.
2. Native Android/iOS rendering handles high-quality export.
3. GPU shaders handle realtime effects.
4. A project model stores clips, effects, text, audio and export settings.
5. Background export reports progress back to Flutter.
