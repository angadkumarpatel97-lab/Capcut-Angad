# Creator Studio — Photo & Video Editor MVP

A clean cross-platform Flutter starter app for Android + iPhone.

## Included in v1
- Home dashboard
- Photo editor screen
- Video editor screen
- Pick photos/videos from device
- Photo preview with live filters
- Brightness / contrast / saturation controls
- Crop/aspect-ratio UI
- Text overlay UI
- Video preview with play/pause
- Video speed controls
- Mute toggle
- Export/share action placeholders
- Dark premium UI

## Run

1. Install Flutter.
2. In this folder run:
   flutter pub get
3. Connect an Android device/emulator or iPhone simulator/device.
4. Run:
   flutter run

## Important
This is an MVP UI + functional preview layer. A production editor still needs a native rendering/export pipeline for:
- frame-accurate video trimming
- multi-track timelines
- 4K encoding
- GPU effects
- photo/video export to the gallery
- background removal and AI enhancement
- undo/redo history
- project persistence

The architecture is intentionally simple so those services can be added without redesigning the UI.

## v2 additions
- Professional timeline editor screen
- Multi-track video/text/audio timeline UI
- Playhead and scrubbing UI
- Tool panels for trim, split, effects, filters, text, music, speed and crop
- Project naming/model
- Export quality selector with 1080p/4K presets
